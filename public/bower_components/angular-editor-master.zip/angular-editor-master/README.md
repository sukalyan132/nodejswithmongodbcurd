angular-editor,1 line is enough
==============

1 line is enough:
```html
<div simditor ng-model='xxx'></div>
```

angular rich text editor with simditor by tower.im

[just visit the home page and check the source code:)](http://wanming.github.io/angular-editor)
